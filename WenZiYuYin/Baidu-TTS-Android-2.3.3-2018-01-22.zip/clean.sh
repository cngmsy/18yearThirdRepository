#!/bin/sh
rm -rf output *.zip  build/* app/build/*